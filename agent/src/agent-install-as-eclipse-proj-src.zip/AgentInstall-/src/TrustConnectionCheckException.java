/**
 * Exception for handling trust connection errors
 */
public class TrustConnectionCheckException  extends Exception
{

	/**
	 * Handling trust connection check exceptions, initializing with error string
	 * @param msg
	 */
	public TrustConnectionCheckException(String msg )
	{
		super(msg); 
	}
	
	/**
	 * Handling trust connection check exceptions, initializing with error string
	 * and exception object
	 * @param msg
	 * @param e
	 */
	public TrustConnectionCheckException(String msg ,Throwable e ) 
	{
		super(msg,e); 
	}
}
