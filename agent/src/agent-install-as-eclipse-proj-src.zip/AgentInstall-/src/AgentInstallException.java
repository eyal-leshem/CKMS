
/**
 * Handling the agent install exceptions
 */
public class AgentInstallException  extends Exception
{
	/**
	 * Handling the agent install exceptions, initializing with message of string
	 */
	public AgentInstallException(String msg) 
	{
		super(msg); 
	}
	
	/**
	 * Handling the agent install exceptions, initializing with message of string and throwable object
	 */
	public AgentInstallException(String msg,Throwable e)
	{
		super(msg,e); 
	}
	
	

}
