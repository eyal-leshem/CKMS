package MykeyTool;

/**
 * Handles exception occurred in implementation.
 * @param msg	-	 description message
 * @param e		-    occurred exception object 
 */
public class MykeyToolIoException extends MyKeyToolBaseExctpion {
	
	public MykeyToolIoException(String message) {
		super(message); 
	}
	
	/**
	 * Handles exception occurred in implementation in IO.
	 * @param msg	-	 description message
	 * @param e		-    occurred exception object 
	 */
	public MykeyToolIoException(String errorMsg, Throwable cause) {
		super(errorMsg, cause);
	}

}
