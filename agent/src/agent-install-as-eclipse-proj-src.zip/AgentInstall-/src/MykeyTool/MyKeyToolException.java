package MykeyTool;


/**
 * Handles key tool exceptions
 */
public class MyKeyToolException extends MyKeyToolBaseExctpion {

	public MyKeyToolException(String message) {
		super(message); 
	}
	
	/**
	 * Handles exception occurred in implementation.
	 * @param msg	-	 description message
	 * @param e		-    occurred exception object 
	 */
	public MyKeyToolException(String errorMsg, Throwable cause) {
		super(errorMsg, cause);
	}

}
