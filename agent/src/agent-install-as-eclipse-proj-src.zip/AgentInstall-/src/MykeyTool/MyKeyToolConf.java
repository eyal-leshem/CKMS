package MykeyTool;

/**
 * Class for storing the configurations of the key tool
 */
public class MyKeyToolConf {
	
	/** default key store **/
	public final String defaultKs="jks";
	
	/** default signature of algorithms used */
	public final String defaultSig="SHA1withRSA";
	
	/** default public encryption algorithm */
	public final String defaultKpa="RSA"; 
	
	/** default security provider */
	public final String defaultProvider="BC"; 
	
	/** key store path */
	String ksPath; 
	
	/** key store password */
	String ksPassword; 
	
	/** key store type */
	String keyStoreType=defaultKs;
	
	/** signature algorithm */
	String sigAlg=defaultSig;  
	
	/** public encryption algorithm */
	String keyPairAlg=defaultKpa; 
	
	/** provider */
	String provider=defaultProvider; 
	
	
	/**
	 * Constructor. 
	 * Initializing the key store path and the password params
	 * All others values will be default.
	 * @param ksPath	-	key store path
	 * @param ksPaswword -	key store password
	 */
	public MyKeyToolConf(String ksPath,String ksPaswword) {
		this.ksPath=ksPath;
		this.ksPassword=ksPaswword;
		
	}
	
	/**
	 * Constructor with three parameters for initializing the keystore type also.
	 * All others values will be default.
	 * @param ksPath	-	 key store path
	 * @param ksPaswword-	 key store password
	 * @param keyStoreType   key store type
	 */
	public MyKeyToolConf(String ksPath,String ksPaswword,String keyStoreType){
	  this(ksPath,ksPaswword); 
	  this.keyStoreType=keyStoreType;
	  
	}
	
	/**
	 * Constructor with 5 parameters. All others values will be default.
	 * @param ksPath	-	 key store path
	 * @param ksPaswword-	 key store password
	 * @param keyStoreType   key store type
	 * @param sigAlg	-	 signature algorithm
	 * @param keyPairAlg - 	 public encryption algorithm
	 */
	public MyKeyToolConf(String ksPath,String ksPaswword,String keyStoreType,String sigAlg,String keyPairAlg){
		  this(ksPath,ksPaswword,keyStoreType); 
		  this.sigAlg=sigAlg; 
		  this.keyPairAlg=keyPairAlg; 		  
	 }
	
	
	/**
	 * Constructor for initializing all the parameters parameters
	 * @param ksPath	-	 key store path
	 * @param ksPaswword-	 key store password
	 * @param keyStoreType   key store type
	 * @param sigAlg	-	 signature algorithm
	 * @param keyPairAlg - 	 public encryption algorithm
	 * @param provider
	 */
	public MyKeyToolConf(String ksPath,String ksPaswword,String keyStoreType,String sigAlg,String keyPairAlg,String provider){
		this(ksPath,ksPaswword,keyStoreType,sigAlg,keyPairAlg);
		this.provider=provider;
	}

	public String getKsPath() {
		return ksPath;
	}

	public void setKsPath(String ksPath) {
		this.ksPath = ksPath;
	}

	public String getKsPassword() {
		return ksPassword;
	}

	public void setKsPassword(String ksPassword) {
		this.ksPassword = ksPassword;
	}

	public String getKeyStoreType() {
		return keyStoreType;
	}

	public void setKeyStoreType(String keyStoreType) {
		this.keyStoreType = keyStoreType;
	}

	public String getSigAlg() {
		return sigAlg;
	}

	public void setSigAlg(String sigAlg) {
		this.sigAlg = sigAlg;
	}

	public String getKeyPairAlg() {
		return keyPairAlg;
	}

	public void setKeyPairAlg(String keyPairAlg) {
		this.keyPairAlg = keyPairAlg;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}
	
	
	
}
