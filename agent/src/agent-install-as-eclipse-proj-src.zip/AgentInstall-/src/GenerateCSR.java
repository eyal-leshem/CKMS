

/**
 * Generates PKCS11 certificate request for apache
 */
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Vector;


import javax.security.auth.x500.X500Principal;
import org.bouncycastle.x509.extension.SubjectKeyIdentifierStructure;

import org.bouncycastle.asn1.x509.*;
import org.bouncycastle.asn1.pkcs.*;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.jce.*;
import org.bouncycastle.asn1.x509.*;
import org.bouncycastle.asn1.pkcs.*;
//import org.bouncycastle.openssl.*;
import org.json.JSONException;
import org.json.JSONObject;

import sun.security.x509.*;
import sun.security.tools.KeyTool;
import sun.security.pkcs.PKCS10;
import sun.security.pkcs.PKCS10Attribute;


import MykeyTool.*;
	 
	/**
	 * This class generates PKCS10 certificate signing request
	 */
	public class GenerateCSR
	{
		/** install service configuration object*/
		static InstallConf conf; 
		
		
	/**
	 * Gets the configuration, initializes key and trust store, generates and send the crs,
	 * installs the certificate after the servers signed it. After installing the certificate
	 * signed, checks if it can establish a trusted connection.
	 * @param argv
	 */
	public static void main(String[] argv)  
	{
		
		MyKeyTool ktTrustStore = null;
		MyKeyTool ktKeyStore = null;
		String cert = null;
		
		
		try
		{
		  getConf(); 
			
		  conf = ArgsConf.setConf(argv,conf); 
			
		  String ksPath=conf.getKsPath();
		  String tsPath=conf.getTrustStorePath(); 
		   
		
		  //make an empty truststore  
		  File trustStoreFile=new File(tsPath); 
		  if(trustStoreFile.exists()) 
			  trustStoreFile.delete(); 
		  
		  //make an empty keystore
		  File keyStoreFile=new File(ksPath); 
		  if(keyStoreFile.exists()) 
			  keyStoreFile.delete(); 
		  
		  //Generate empty-truststroe 
		  ktTrustStore=new MyKeyTool(new MyKeyToolConf(tsPath,"a10097")); 
		  try
		  {
			ktTrustStore.createNewKs();
		  }
		  catch (MyKeyToolBaseExctpion e)
		  {
			throw new AgentInstallException("can't create new keystore at path: "+ tsPath); 
		  }
		  
		  //Generate empty-keystore 
		  ktKeyStore = new MyKeyTool(new MyKeyToolConf(ksPath,"a10097")); 
		  try 
		  {
			  ktKeyStore.createNewKs();
		  }
		  catch (MyKeyToolBaseExctpion e)
		  {
			throw new AgentInstallException("can't create new keystore at path: "+ ksPath);
		  }
		  
		
		  //add the ca certificate to the new keystore  
		  InputStream caCertStream;
		  try
		  {
			
			caCertStream=new FileInputStream(new File(conf.getServerCaPath()));	  
			ktTrustStore.addTrustCert( caCertStream, "myCa");
			caCertStream.close();
			
		  }
		  catch (Exception e)
		  {
			throw new AgentInstallException("can't add the ca certificate to truststore", e);
		  }
		 
		  try
		  {
			//add the ca certificate to the new keystore  
			caCertStream = new FileInputStream(new File(conf.getServerCaPath()));	  
			ktKeyStore.addTrustCert( caCertStream, "myCa");
			caCertStream.close();
		  }
		  catch (Exception e)
		  {
			  throw new AgentInstallException("can't add the ca certificate to keystorw", e);
		  }
		 
		  
		  //Generate certificate request and write it to string 
		  OutputStream out = new ByteArrayOutputStream(); 	
		  try
		  {
			  ktKeyStore.genartePrivatekey("my key", "cn=a,ou=a,o=a,l=a,s=a,c=a");
		  }
		  catch (MyKeyToolBaseExctpion e) 
		  {
			throw new AgentInstallException("prolebm to genarte a privte key with name: my key and dname: cn=a,ou=a,o=a,l=a,s=a,c=a ",e ); 
		  }
	    
		  try
		  {
	    	ktKeyStore.genrateCsr("my key",out);
		  }
		  catch (MyKeyToolBaseExctpion e) 
		  {
			throw new AgentInstallException("can't genrate csr from the key: my key", e); 
		  }
	    
		  //make string from the csr 
		  String csr = out.toString(); 
	
		  //register and get certificate sign by the Ca 
		  cert=Register.register(csr,conf);
		 
		}
		catch (AgentInstallException e) 
		{
			installFail(e); 
		}
		

		//install the replay and chek the trust connection can establish 
		try
		{
			ktKeyStore.installReply("my key", new ByteArrayInputStream(cert.getBytes()));
		}
		catch (MyKeyToolBaseExctpion e)
		{
			failToImportTheAnswer(e); 
		}
		
		try
		{
			TrustConnectionChek.connect(conf);
		}
		catch (TrustConnectionCheckException e) 
		{
			failToCreateTrustConnection(e); 
		}
		  
	  
		
	}
	
	/**
	 * For the case that after installing the certificate signed by a server, the service
	 * failed to establish a trusted connection. Handles this error.
	 * @param e		-	the exception occurred
	 */
	private static void failToCreateTrustConnection(
			TrustConnectionCheckException e) 
	{
		System.out.println("After successful registration process");
		System.out.println("can't create trust connection with server");
		System.out.println("the problem is: "+ e.getMessage());
		System.out.println("full exception is: "); 
		e.printStackTrace(); 
		System.exit(0);
		
	}

	/**
	 * For the error of certificate installing
	 * @param e	-	 the exception occurred
	 */
	private static void failToImportTheAnswer(MyKeyToolBaseExctpion e) 
	{
		System.out.println("After successful registration process");
		System.out.println("can't install the server certifcate in the agent");
		System.out.println("the problem is: "+ e.getMessage());
		System.out.println("full exception is: "); 
		e.printStackTrace(); 
		System.exit(0); 
		
	}

	/**
	 * For the error of agent installing
	 * @param e	-	 the exception occurred
	 */
	private static void installFail(AgentInstallException e) 
	{
		System.out.println("can't install the agnet");
		System.out.println("the problem is: "+ e.getMessage());
		System.out.println("------------------------------");
		System.out.println("full exception is: "); 
		e.printStackTrace();
		System.exit(0);
		
		
	}

	/**
	 * 
	 * @throws AgentInstallException
	 */
	private static void getConf() throws AgentInstallException
	{
		try
		{
			getConf("conf.cnf"); 
		}
		catch (AgentInstallException e) 
		{
			throw new AgentInstallException("can't genarte configutationn from file conf.cnf"); 
		}
		
		
		
	}
	
	
	/**
	 * Gets the properties string from the config file and creates an InstallConf object.
	 * @param path	-	path of the configurations file that contains json format strings
	 * @throws AgentInstallException
	 */
	private static void getConf(String path) throws AgentInstallException
	{
		
		String jsonConfStr;
		
		//read the json string that contains the properties from the file 
		File confFile = new File(path); 
		try
		{
			FileReader fr = new FileReader(confFile);
			char[] buffer = new  char[(int)confFile.length()];
			fr.read(buffer);
			jsonConfStr = new String(buffer); 
		}
		
		catch (IOException e) 
		{
			throw new AgentInstallException("can't read fron cof file in Path "+ path, e); 
		}
		
		//and use the json conf contractor 
	   	conf= new InstallConf(jsonConfStr);

	}
	
	


	
	

 
}

 
