package message;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * Message class for storing tasks data
 */
public class Message 
{
	/** unique message identifier */
	String ID;
	
	/** if the task depends in submission of another task
	 * (for example: key install depends on generating key task) 
	 * this member contains the task id that current task depends on*/
	String dependOn;  

	/** agent unique identifier */
	String agentId;   
 
	/** Date+time of sending */
	Timestamp timeStamp;  
 
	/** implementor unique identifier */
	String implementorID; //
 
	/** string with data (public key...)*/
	String msgData;
 
	/** the kind of the data */
	String kind;  
	
	/** algorithm of encryption*/
	String alg; 

	public String getAlg() {
		return alg;
	}

	public void setAlg(String alg) {
		this.alg = alg;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public Timestamp getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getImplementorID() {
		return implementorID;
	}

	public void setImplementorID(String implementorID) {
		this.implementorID = implementorID;
	}

	public String getMsgData() {
		return msgData;
	}
	
	public void setMsgData(String msgData){
		this.msgData = msgData;
	}

	public void setMsgData(String msgData,boolean replace) {
		if(replace){
			msgData=msgData.replace('#','\n');
			msgData=msgData.replace('*','\r');
		}
		this.msgData = msgData;
	}


	
	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getDependOn() {
		return dependOn;
	}

	public void setDependOn(String dependOn) {
		this.dependOn = dependOn;
	}
}