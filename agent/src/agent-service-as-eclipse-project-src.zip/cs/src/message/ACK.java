package message;

/**
 * ACK class for storing acknowledge data about the done task
 */
public class ACK 
{
	
	/** indicates if an error occured during the submission */
	boolean	OK = true;
	
	/** task unique identifier */
	String	taskId; 
	
	/** implementor unique identifier */
	String	implemntorName;
	
	/** return data to the server after submitting the task (e.g. key generated) */
	String	data;
	
	/** algorithm for the data encryption */
	String  dataAlg;
	
	/** kind of the data returned to the server */
	String  dataKind;

	/** in case of problem occurred: message contains the error string */
	String  errorMsg;
	
	/** in case of problem occured: message contains the full exceptions record*/
	String  fullExceptionString; 
	
	
	
	public String getFullExceptionString() {
		return fullExceptionString;
	}
	public void setFullExceptionString(String fullExceptionString) {
		this.fullExceptionString = fullExceptionString;
	}
	public String getDataAlg() {
		return dataAlg;
	}
	public String getDataKind() {
		return dataKind;
	}
	public void setDataKind(String dataKind) {
		this.dataKind = dataKind;
	}
	public void setDataAlg(String dataAlg) {
		this.dataAlg = dataAlg;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public boolean isOK(){
		return OK;
	}
	public void setOK(boolean oK) {
		OK = oK;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getTaskId() {
		if(taskId==null){
			return "0"; 
		}
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getImplemntorName() {
		return implemntorName;
	}
	public void setImplemntorName(String implemntorName) {
		this.implemntorName = implemntorName;
	} 
	
	

}
