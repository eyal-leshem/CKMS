package Implemtor;

import java.io.File;

import message.ACK;
import message.Message;
import Commands.Command;
import Commands.CommandFactory;
import Logger.AgentServiceLogger;
import Manager.AgentServiceConf;
import exceptions.AgentServiceException;
import exceptions.ExceptionHelper;


/** 
 * Implementor Manager singleton class.
 * Implements tasks submission according the data passed in 
 * Message task object, by passing it to Command object 
 * with the required plugin and implementor. Gets the submission
 * result from implementor, failure or success and creates ACK 
 * result object. 
 * 
 * All the plugins stored in PluginManager according identifiers.
 * All the Command objects stored in CommandFactory according 
 * defined names of commands.
 * 
 *  */
public class ImplementorManager 
{
	
	/** Configuration object updated by the messages from server */
	private static 	AgentServiceConf		conf; 
	
	/** Implementor Manager singleton  instance */
	static 			ImplementorManager 		inst = null;
	
	/** Command factory for creating commands */
	private			CommandFactory			commandFactory = CommandFactory.getInstance(); 
	
	/** Plugin Manager for managing plugins */
	private static 	PluginManger 			pluginManger;
	
	/** Agent Service Logger for storing running logs */
	private static  AgentServiceLogger		logger = AgentServiceLogger.getInstance();
	
	/** Flag for stopping the endless loop. Changed by message from server */
	static boolean stopped;

	
	
	
	/**
	 * The implementor manager object is a singleton because we have 
	 * only one in our program.
	 *
	 * @return an instance of this implementor manger 
	 * @throws Exception
	 */
	public static ImplementorManager getInstance() throws AgentServiceException
	{
		if(inst == null)
		{
			inst = new ImplementorManager(); 
		}
		return inst;
		
	}
	
	
	/**
	 * Private constructor for sure that only one instance can be created
	 * While called, starts the run of plugin manager with the path of
	 * plugin directory, for observing this folder for new plugins jars added.
	 *  
	 * @throws AgentServiceException
	 */
	private ImplementorManager() throws AgentServiceException 
	{
			stopped = false;
			
			conf = AgentServiceConf.getInstance();
			try
			{
				pluginManger = PluginManger.getInstance();
			} catch (Exception e)
			{
				
				throw new AgentServiceException("can't get intance of plugin manger",e);
			}
			
			String pluginDirPath=new File(".").getAbsolutePath()+System.getProperty("file.separator")+"plugins";
			pluginManger.startObserving(pluginDirPath);
		
		
	}

	
	/**
	 * Commits a task specified in the Message object passed as input.
	 * Gets the implementor id for the task, specified in the message, 
	 * sends the task for the Command object with required 
	 * implementor for submission, according the command we got in the
	 * message.
	 * Command returns ACK object if none exception occurred
	 * during commiting the task, otherwise - throws an exception.
	 * 
	 * <b>If an exception occurred <b> - writes into the errors log
	 * 
	 * <b>In both the cases <b> - initializes the ACK object with all the 
	 * relevant properties (implementor name, task identifier), and 
	 * returns the object.
	 * 
	 * @param msg	 - Message object with task for commit
	 * @return	     - ACK object with submission data
	 */
	public ACK commitTask(Message msg) 
	{
		
		ACK ack = new ACK();
		
		synchronized (inst)
		{
			//get the implementor 
			Implementor imp = getImplemntor(msg);	
			
			try
			{
				//implemtor nop mean mission for agent without  implemtor 
				if (imp == null && !msg.getImplementorID().equals("nop"))
				{
					noSouchImp(msg.getImplementorID()); 
				}
				
				//Execute the command 
				Command command = commandFactory.getCommand(msg); 
				ack = command.excute(imp, msg);
				
				//Everything go well
				ack.setOK(true); 
			}
			
			//case of exception 
			//create fail message to the server 
			catch (AgentServiceException e)
			{
				ack.setOK(false);
				ack.setErrorMsg(e.getMessage());
				ack.setFullExceptionString(ExceptionHelper.getCustomStackTrace(e)); 
				logger.error("problem to confrim the task - "+msg.getID());
			}
			
			//the relevant properties for each ack 
			finally
			{
				ack.setTaskId(msg.getID());
				
				//get the implementor name
				if(imp != null)
					ack.setImplemntorName(imp.getName());
				else 
					ack.setImplemntorName("nop"); 
				
				//report to the log on error 
				logger.error("implemtor '"+msg.getImplementorID()+"' perfrom task "+ msg.getID());
			}
		} 
		return ack; 
	}
	
	
	/**
	 * Throws exception for the case that specified implementor in the message
	 * does not exists
	 * @param impName	- required implementor identifier
	 * @throws AgentServiceException
	 */
	private void noSouchImp(String impName) throws AgentServiceException 
	{
		throw new AgentServiceException("no such implmentor : "+impName); 		
	}
	
	private Implementor getImplemntor(Message msg) {	
		 return 	pluginManger.getImplementor(msg); 
	}
		
	public static AgentServiceConf getConf() {
		return conf;
	}
	
	/**
	 * Returns if the main loop of the agent run was stopped by the task from server
	 * @return true if stopped
	 */
	public boolean isStopped()
	{
		return stopped;
	}
	
	/**
	 * Stops the main loop flag run
	 */
	public void stopMainLoop()
	{
		stopped = true;
	}

}
