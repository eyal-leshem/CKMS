package Implemtor;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ConcurrentHashMap;

import Commands.newInstanceCommand;
import Logger.AgentServiceLogger;
import Manager.AgentServiceConf;
import Manager.Communicate;

import exceptions.AgentServiceException;

import message.Message;

/**
 * Manages plugins and instances loading and storage. 
 * Loading plugins while starting the service - all the items
 * that are in plugins folder.
 * Watching plugins folder during the run for load new plugin
 * when added into the folder. 
 * 
 * Stores plugins according theis names, 
 */
public class PluginManger implements Observer
{
	/** Factory object for creating new plugins */
	PluginFactory 						pluginFactory = PluginFactory.getInstance();
	
	/** listener for the changes in folder with plugins*/
	ListenPluginDir 					watcher;
	
	/** Implementors map for storing Implementors objects according their names*/
	Map<String,Implementor> 			implemtors = new  ConcurrentHashMap<String,Implementor>();
	
	/** Map with plugin classes map through unique names */
	Map<String,Class>					plugins = new ConcurrentHashMap<String, Class>();
	
	/** instance of this class for make it a singleton */
	static PluginManger 				inst = null;
	
	/** configurations object of the service */
	AgentServiceConf					conf = null; 
	
	/** Flag for stopping the endless loop. Changed by message from server */
	boolean stopped;
	
	
	/**
	 * Getting list of classes with plugins to load from plugins folder.
	 * Load the plugin instances into implementors map according it's unique name.
	 * For each loaded item - call method to inform the server
	 * about new plugin added.
	 * 
	 * @throws AgentServiceException
	 */
	public PluginManger() throws AgentServiceException
	{
		
		//plugins path 
		String pluginDirPath = new File(".").getAbsolutePath()+System.getProperty("file.separator")+"plugins"; 
			
		ArrayList<Class> pluginsArray;
		
		conf = AgentServiceConf.getInstance();
		
		
		//load the implemtor array 
		try 
		{
			pluginsArray = pluginFactory.getClassArr(pluginDirPath);
		} catch (AgentServiceException e)
		{
			throw new AgentServiceException("can't load the arraylist of plugins", e);
		}
		
					
		Communicate net = new Communicate(); 
	
		//put the implementors into an hash-map  
		for (Class aClass : pluginsArray) 
		{
			//get class name 
			String pluginName = aClass.getName().substring("Implemtor.".length());
			
			//put in the plugin table and update the server
			plugins.put( pluginName , aClass ); 
			net.newImpInform(pluginName, conf); 
		}	
		
		
		//load the all install instances of that plugin factory   
		try 
		{
			PluginInstanceFactory pif = PluginInstanceFactory.getInstance(); 
			implemtors = pif.getImps(plugins); 
			
		} catch (AgentServiceException e) 
		{
			throw new AgentServiceException("problem to ge the implementors from plugin factory"); 
		}
		
	}
	

	/**
	 * Returns the instance of object if already exists, otherwise
	 * creates new. This promises it will always be only one object instance.
	 * 
	 * @return singleton instance if plugin manager object
	 * @throws AgentServiceException
	 */
	public static PluginManger getInstance() throws AgentServiceException
	{
		if(inst == null)
		{
			inst = new PluginManger();
		}
		return inst;
		
	}
	
	public Implementor getImplementor(Message msg)
	{
		return  implemtors.get(msg.getImplementorID());
	}
	
	//_________________________________________________________________________________
	/**
	 * Method that starts observing the changes in folder specified in folderPath.
	 * The watcher runs in thread until it's stopped.
	 * Plugin Manager adds itself as an observer for the changes in folder. 
	 *  
	 * @param folderPath	-	The path of folder to watch
	 */
	public void startObserving(String folderPath)
	{
		watcher = new ListenPluginDir();
		watcher.addObserver(this);
		watcher.setFolderPath(folderPath); 
		
		//start watcher thread
		new Thread(new Runnable()
		{
			@Override
			public void run()
			{
				watcher.run();
			}			
		}).start();
	}
	
	/**
	 * pause for watching folder
	 */
	public void pauseWatcher()
	{ 
		watcher.pause(); 
	}
	
	/**
	 * Resuming the thread that watch to the user folder
	 */
	public void resumeWatcher()
	{
		synchronized (watcher)
		{
			watcher.notify();
			watcher.resume();
		}
	}
	
	
	/**
	 * Method called from listenPluginDir object when a change occurred
	 * arg1 - the object with the change of the type PluginChange. Contains
	 * 			path - string with the path of jar that was removed/created
	 * 			type - CREATED/DELETED
	 */
	@Override
	public void update(Observable arg0, Object arg1) 
	{
		try 
		{	
			PluginChange changeObj = (PluginChange)arg1;
			
			//if the change was creation of new jar - add to implementors map new Implementor
			if(changeObj.change == PluginChange.changeType.CREATED)
			{
				synchronized (inst)
				{
					Class aClass = pluginFactory.getOneClass(changeObj.path);
					
					Communicate net= new Communicate();
					//if the file was a correct jar
					if(aClass != null)
					{
						//get class name 
						String pluginName=aClass.getName().substring("Implemtor.".length());
						
						//put in the plugin table and update the server
						plugins.put( pluginName , aClass ); 
						net.newImpInform(pluginName, conf); 
					}
				}
			}
			
			//if the change was the removal of existed jar - remove from implementors map
			if(changeObj.change == PluginChange.changeType.DELETED)
			{
				synchronized (inst)
				{
					String path = changeObj.path;
					implemtors.remove(path.substring(0, path.indexOf(".jar")));
				}
			}
			
		} 
		catch (Exception e) {/*a bad plugin*/	}
		
	}

	
	/**
	 * Adds new instance of specified implementor with it's parameters
	 * Calls for method to install the new plugin instance in the system.
	 * Stores the new instance in the map of all the implementors.
	 * 
	 * 
	 * @param plugin	-	the required plugin name
	 * @param parms 	-	parameters of this instance
	 * @return			-	string with instance name and algorithms separated by ','
	 * @throws AgentServiceException
	 */
	public String addNewInstance(String plugin,String parms) throws AgentServiceException
	{
		
		PluginInstanceFactory pif = PluginInstanceFactory.getInstance(); 
		
		Implementor imp;
		try 
		{
			Class pluginClass = plugins.get(plugin); 
			imp = pif.installNewImplementorInstance(pluginClass,parms);
		} catch (AgentServiceException e) {
			throw new AgentServiceException("can not install new instance of this implemntor implemntor",e); 
		} 
		
		
		implemtors.put(imp.getName(),imp); 
		
		String algs = getAlgString(imp); 
		
		return imp.getName()+","+algs; 
	
	}

	/**
	 * Returns all the algorithms of required implementor
	 * @param imp	-	implementor for getting it's algorithms
	 * @return string with the algorithms separated by ','
	 * @throws AgentServiceException if failed to get the algorithms
	 */
	private String getAlgString(Implementor imp) throws AgentServiceException 
	{
	
		ArrayList<String> algs;
		try 
		{
			algs = imp.getAlgorithms();
		} catch (ImplementorExcption e) {
			throw  new AgentServiceException("can not get the algorithems of the implemntor"); 
		} 
		
		
		StringBuilder ret = new StringBuilder(""); 
		
		for(String alg:algs){
			ret.append(alg+","); 
		}
		
		if(ret.toString().length()>0)
			return ret.toString().substring(0,ret.length()-1); 
		return ""; 
	}


	private void ImplemntorNameNotAvailable() {
		// TODO Auto-generated method stub
		
	}
	
	

}
