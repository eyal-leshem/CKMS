package Implemtor;

/**
 * Class for changes in plugins jars files in folder that is being watched
 *
 */
public class PluginChange
{
	/** path to the file */
	public String path = "";
	
	/** change type (CREATED, DELETED)*/
	public changeType change;
	
	
	static public enum changeType
	{
	    CREATED, DELETED
	}
	
	/**
	 * Constructor for deleting/creating event
	 * @param oldPath
	 * @param type the type of the change defined as enum CREATED\DELETED
	 */
	public PluginChange(String oldPath, changeType type)
	{
		//initialize the name
		path = new String(oldPath);
		change = type;
	}
}
