package Implemtor;

import java.io.IOException;
import java.math.BigInteger;
import java.security.cert.Certificate;
import java.util.ArrayList;

import javax.crypto.SecretKey;

/**
 * Implementor abstract class. Provides an interface for methods have 
 * to be implemented by each plugin implementor.
 */
public abstract class Implementor 
{
	/** unique implementor identifier name */
	protected String name;
	
	public Implementor() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * build the implementor
	 * 
	 * @param params - json string that contain parameters for this key Store 
	 * @throws Exception 
	 */
	public Implementor(String params) throws Exception 
	{
		throw new Exception("unimplement"); 
	}
	
	
	public String getName()
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	/**
	 * Generates private and public keys pair
	 * @param dName	- initialization distinguished value string
	 * @param alias	- unique alias for keystore entries
	 * @return
	 * @throws ImplementorExcption
	 */
	public Certificate	genrateKeyPair(String dName,String alias) throws ImplementorExcption
	{
		throw new ImplementorExcption("unimplemnt method"); 
	}
	
	/**
	 * Generates secret key
	 * @param alg	- algorithm
	 * @param alias	- unique alias for keystore entries
	 * @return
	 * @throws ImplementorExcption
	 */
	public SecretKey	genrateSecertKey(String alg,String alias) throws ImplementorExcption
	{
		throw new ImplementorExcption("unimplemnt method"); 
	} 
	
	/**
	 * Installs secret key in the database
	 * @param key	- SecretKey object for install
	 * @param alias	- unique alias for keystore entries
	 * @return true in success
	 * @throws ImplementorExcption
	 */
	public  boolean		installSecertKey(SecretKey key, String alias) throws ImplementorExcption
	{
		throw new ImplementorExcption("unimplemnt method"); 
	} 
	
	/**
	 * Installs certificate for trust
	 * @param cert	-	Certofocate object for install
	 * @param alias	- unique alias for keystore entries
	 * @return true in success
	 * @throws ImplementorExcption
	 */
	public boolean		installTrustCert(Certificate cert ,String alias) throws ImplementorExcption 
	{
		throw new ImplementorExcption("unimplemnt method"); 
	}
	
	/**
	 * Adds the certificate into revocation list
	 * @param serialNumber
	 * @return true in success
	 * @throws ImplementorExcption
	 */
	public boolean		addToCrl(BigInteger serialNumber)  throws ImplementorExcption
	{
		throw new ImplementorExcption("unimplemnt method"); 
	}
	
	/**
	 * Removes certificate from the trusts
	 * @param serialNumber	-	of certificate for removal
	 * @return true in success
	 * @throws ImplementorExcption
	 */
	public boolean		removeCertificate(BigInteger serialNumber)  throws ImplementorExcption
	{
		throw new ImplementorExcption("unimplemnt method"); 
	}

	/**
	 * Returns algorithms for this implementor
	 * @return	ArrayList with String with identifiers of algorithms
	 * @throws ImplementorExcption
	 */
	public ArrayList<String> getAlgorithms() throws ImplementorExcption
	{
		
		return new ArrayList<String>(); 
	}
}
