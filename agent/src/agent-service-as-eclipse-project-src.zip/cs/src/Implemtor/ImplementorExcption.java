package Implemtor;

/**
 * Cares for exceptions of implementors
 */
public class ImplementorExcption extends Exception 
{
	

	private static final long serialVersionUID = -7648034789960810239L;

	/**
	 * Constructor with one parameter
	 * @param msg	- exception message
	 */
	public ImplementorExcption(String msg) {
		super(msg); 
	}
	
	/**
	 * Constructor with two parameters
	 * @param msg	- exception message
	 * @param e		- exception object
	 */
	public ImplementorExcption(String msg,Throwable e) {
		super(msg,e); 
	}
	

}
