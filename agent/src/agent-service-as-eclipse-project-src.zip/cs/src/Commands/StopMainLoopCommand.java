package Commands;

import message.ACK;
import message.Message;
import Implemtor.Implementor;
import Implemtor.ImplementorManager;
import exceptions.AgentServiceException;

/**
 * Stops the main loop from getting and committing a tasks.
 */
public class StopMainLoopCommand implements Command
{

	/**
	 * Stops the main loop from getting and committing a tasks.
	 * After stopping the loop, restarting of the process run
	 * can be made from the host itself only.
	 * If committed this task without errors - returns new 
	 * ACK object for sending to server.
	 * In case of errors - throws an exception. 
	 */
	@Override
	public ACK excute(Implementor imp, Message msg)
			throws AgentServiceException
	{
		ImplementorManager impManager = ImplementorManager.getInstance();
		
		//call method for stop the main loop
		impManager.stopMainLoop();
		
		//create and return the ack message
		ACK ack = new ACK(); 
		return ack ; 
	}

}
