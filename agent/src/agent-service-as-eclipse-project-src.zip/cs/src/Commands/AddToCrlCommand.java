package Commands;

import java.math.BigInteger;

import message.ACK;
import message.Message;
import Implemtor.Implementor;
import Implemtor.ImplementorExcption;
import exceptions.AgentServiceException;

/**
 * Adding the certificate into revocation list.
 * Implements command interface and execute method.
 * Revocates the certificate according it's serial number,
 * got from message.
 * 
 */
public class AddToCrlCommand implements Command 
{

	/**
	 * <b>Adds certificate into revocation list.<b>
	 * Gets as input an implementor instance that implements
	 * the method.
	 * Calls implementor method for add the certificate into
	 * revocation list according it's serial number it got
	 * from the message data.
	 * If committed without errors - returns new ACK object
	 * for sending to server.
	 * In case of errors - throws an exception. 
	 */
	@Override
	public ACK excute(Implementor imp, Message msg)
			throws AgentServiceException {
		
			//get the serial number form msg data
			BigInteger serial;
			try
			{
				serial=new BigInteger(msg.getMsgData());
			}catch (Exception e) 
			{
				throw new AgentServiceException("can't create big integer from seriral number -"+msg.getMsgData(), e); 
			}
			
			//call to implementor that will ad it to crl 
			try
			{
				imp.addToCrl(serial);
			} catch (ImplementorExcption e) 
			{
				throw new AgentServiceException("imlemntor -"+imp.getName()+"can't add this cert to the crl" ,e); 
			} 
			
			//return the ack 
			ACK ack=new ACK();
			ack.setOK(true); 
			return ack; 
			
		 
	}

}
