package Commands;

import exceptions.AgentServiceException;
import message.ACK;
import message.Message;
import Implemtor.Implementor;

/**
 * Interface for all the commands passed from server to the agent
 */
public interface Command
{
	/**
	 *  Passes the command for implementor execution 
	 * 
	 * @param imp - the implementor object  
	 * @param msg - the message to send 
	 * @return  ACK - for send back to the server ;    
	 * @throws Exception
	 */
	public ACK excute(Implementor imp,Message msg) throws AgentServiceException; 

}
