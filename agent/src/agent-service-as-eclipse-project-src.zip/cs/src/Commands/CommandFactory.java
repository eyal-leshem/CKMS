package Commands;

import exceptions.AgentServiceException;
import message.Message;

/**
 * Generates command object according the defined command name
 */
public class CommandFactory
{
	
	/** private instance to make the object a singleton */
 	private static CommandFactory inst = null;
 	
 	private CommandFactory(){
 		
 	}
 	
 	/**
 	 * Creates new instance if not created yet, or return exists
 	 * @return commandFactory instance
 	 */
 	public static CommandFactory getInstance()
 	{
 		if(inst == null)
 		{
 			return new CommandFactory(); 
 		}
 		return inst; 
 	}
 	
 	/**
 	 * Returns a command according the name from Message.
 	 * <b>Supported commands:<b>
 	 * 			- generate key Pair (generate public+private key pair)
 	 * 			- generate secret (generates secret key)
 	 * 			- install cert   (store passed certificate as trusted)
 	 * 			- install secret (store passed secret key in db)
 	 * 			- change conf	(change agent configuration)
 	 * 			- remove certifcate (removes the certificate from db)
 	 * 			- add to crl (revocates certificate)
 	 * 			- new inst (creates new plugin instance)
 	 * @param msg	-	message contains the command kind
 	 * @return relevant command object for each message 
 	 * @throws AgentServiceException	- if no command suitable to the
 	 * command name passed in message.
 	 */
 	public  Command getCommand(Message msg) throws AgentServiceException{
		if(msg.getKind().equals("generate key Pair"))	    return new GenrateKeyPairCommand(); 
		if(msg.getKind().equals("generate secret"))			return new GenrateSecertCommand();
		if(msg.getKind().equals("install cert"))        	return new InstallCertCommand(); 	
		if(msg.getKind().equals("install secret"))			return new InstallSecertCommand(); 
		if(msg.getKind().equals("change conf"))				return new ChangeConfCommand();
		if(msg.getKind().equals("remove certifcate"))		return new DelCertCommand();
		if(msg.getKind().equals("add to crl"))				return new AddToCrlCommand();
		if(msg.getKind().equals("new inst"))				return new newInstanceCommand();
		if(msg.getKind().equals("stop loop"))				return new StopMainLoopCommand();
		
		
		throw new  AgentServiceException("no such task suiteable to - "+msg.getKind()); 
 	
 	}

}
