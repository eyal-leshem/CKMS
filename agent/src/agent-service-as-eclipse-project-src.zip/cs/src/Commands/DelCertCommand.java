package Commands;

import java.math.BigInteger;

import message.ACK;
import message.Message;
import Implemtor.Implementor;
import Implemtor.ImplementorExcption;
import exceptions.AgentServiceException;

/**
 * Removes the certificate from the keystore according serial number
 */
public class DelCertCommand implements Command
{

	/**
	 * Passes to implementor for removing the certificate from the keystore according serial number
	 * Gets as input the implementor object and the 
	 * Message object with the task.
	 * If committed this task without errors - returns new 
	 * ACK object for sending to server.
	 * In case of errors - throws an exception. 
	 */
	@Override
	public ACK excute(Implementor imp, Message msg)
			throws AgentServiceException 
	{
		
		BigInteger serial=new BigInteger(msg.getMsgData());
		
		//call to implementor that will remove the cert
		try
		{
			imp.removeCertificate(serial);
		} catch (ImplementorExcption e)
		{
			throw new AgentServiceException("imlemntor -"+imp.getName()+"can't remove this cert" ,e); 
		} 
		
		//return the ack 
		ACK ack=new ACK();
		ack.setOK(true); 
		return ack; 
		
		
	}

}
