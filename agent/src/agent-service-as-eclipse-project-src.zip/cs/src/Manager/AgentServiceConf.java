package Manager;

import java.util.ArrayList;

import org.json.*;

import Implemtor.PluginManger;

import exceptions.AgentServiceException;


/**
 * AgentServiceConf singleton class for storing the configuration of agent.
 * The configuration can be managed from server.
 */
public class AgentServiceConf 
{
	
	/** agent unique identifier name*/
	private 	String agentName;
	
	/** URL for sending acks to the server*/
	private		String urlSendAck;
	
	/** URL for getting tasks from the server */
	private		String urlGetTask; 
	
	/** URL for new implementor acknowledgments to the server */
	private		String urlNewImplemtor; 
	
	/** sleep time for endless main loop */
	private		int	   sleepTime; 
	
	/** password for keyStore */
	private 	String password;
	
	
	
	
	/** private instance of singletone object */
	private	static AgentServiceConf inst = null;  
	
	
	/**
	 * Private constructor for ensure it will be only one instance.
	 * Initializes class members with the values from json string 
	 * it got as input.
	 * 
	 * @param jsonConfStr	- string with all the configuration
	 * @throws AgentServiceException - in case of error of json string					
	 */
	private AgentServiceConf(String jsonConfStr) throws AgentServiceException  
	{
		JSONObject json;
	
		try
		{
			json = new JSONObject(jsonConfStr); 
			
			agentName = json.getString("agentName");
			urlSendAck = json.getString("urlSendAck"); 
			urlGetTask = json.getString("urlGetTask"); 
			urlNewImplemtor = json.getString("urlNewImplemtor"); 
			password = json.getString("password"); 
			sleepTime = json.getInt("sleepTime");
			
		}
		catch (JSONException e) 
		{
			throw new AgentServiceException("can't parse legal json from the string :\n "+jsonConfStr,e); 
		}	
				
				
	}
	
	
	/**
	 * Creating and installing the new configuration from the json 
	 * string that we got.
	 * 
	 * @param jsonStr	-	with all the parameters and it's values
	 * @return	AgentServiceConf object
	 * @throws AgentServiceException
	 */
	public static AgentServiceConf IntallConf(String jsonStr) throws AgentServiceException
	{
		AgentServiceConf conf = new AgentServiceConf(jsonStr); 
		inst = conf; 
		return inst;
	}
	
	
	/**
	 * Returns the AgentServiceConf instance
	 * @return
	 * @throws AgentServiceException	- in case that instance is null
	 */
	public static AgentServiceConf getInstance() throws AgentServiceException
	{
		if(inst == null)
			throw new AgentServiceException("need to install befor use via IntallConf(String jsonStr)");
		return inst; 
	}
	
	
	
	
	//////setters and geter's 
	public int getSleepTime() {
		return sleepTime;
	}
	public void setSleepTime(int sleepTime) {
		this.sleepTime = sleepTime;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getUrlSendAck() {
		return urlSendAck;
	}
	public void setUrlSendAck(String urlSendAck) {
		this.urlSendAck = urlSendAck;
	}
	public String getUrlGetTask() {
		return urlGetTask;
	}
	public String getUrlNewImplemtor() {
		return urlNewImplemtor;
	}

	public void setUrlNewImplemtor(String urlNewImplemtor) {
		this.urlNewImplemtor = urlNewImplemtor;
	}

	public void setUrlGetTask(String urlGetTask) {
		this.urlGetTask = urlGetTask;
	}

	public String getPassword() {
		return password;
	}

	
	
	
	
	

}
