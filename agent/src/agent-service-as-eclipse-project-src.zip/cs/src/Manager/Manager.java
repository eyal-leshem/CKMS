package Manager;



import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import exceptions.AgentServiceException;
import exceptions.ExceptionHelper;
import Implemtor.ImplementorManager;
import Logger.AgentServiceLogger;
import message.ACK;
import message.Message;



/** Manager class.
 * The main class for managing the flow of the Agent Service.
 * <br>
 * <b>Running in the endless loop:</b><br>
 * - Getting tasks from the server,<br>
 * - Committing the tasks, sending an answer.<br>
 * - Sleeps X time defined by the configuration.<br>
 * 
 * Uses ImplementorManager object - for implementations of
 * tasks submissions. 
 *  */
public class Manager 
{

	/** Configuration object updated by the messages from server */
	static AgentServiceConf conf; 
	
	
	
	/**
	 * <b>Running in endless loop :</b> <br>
	 * 	1. ask the server for tasks <br>
	 * 	2. executes the tasks <br>
	 *  3. send an ack to the server, contains errors log if occured<br>
	 *  3. sleep x time <br>
	 * 
	 *  <b>Uses:</b>
	 *  -  Communicate object for all communication operations with the server.
	 *  -  Parser object for parsing the messages in json format it got from the
	 *  server and creating Message object.
	 *  -  Implementor manager object contains and manages implementor for tasks
	 *  committing. 
	 *  
	 * @param args
	 */
	public static void main(String[] args)  
	{
		
		AgentServiceLogger logger = AgentServiceLogger.getInstance();
		logger.init();
		
		//get the configuration  of the agent service 
		try 
		{
			getConf();
			
			Communicate net = new Communicate();
			
			//install all models 			 
			Parser parser = new Parser();
			
			ImplementorManager impManager = ImplementorManager.getInstance(); 
		 
					
			//run for ever unless got stop command from the server
			while(!(impManager.isStopped()))
			{
				//get and updates from the net 
				String updates = net.getNewTasks();
				
				if(updates != null && !updates.equals("null"))
				{
					ArrayList<Message> messages = null;
				    
					//parse the string message that get from the server 
					try
					{
						messages = parser.parseMessage(updates);
					}
					catch (Exception e)
					{
						//error while parsing send acknowledgment to the server  
						ACK ack = new ACK(); 
						ack.setOK(false); 
						ack.setErrorMsg("problem to parse update string -"+updates); 
						ack.setFullExceptionString(ExceptionHelper.getCustomStackTrace(e)); 
						ack.setTaskId("0"); 
						net.sendResponse(ack, conf); 
					}
					
					//commit all the tasks 
					if(messages != null)
					{
						for(Message msg:messages)
						{
							ACK retMsg = impManager.commitTask(msg);
							net.sendResponse(retMsg); 
						}	
					}
					
				}//end of if(updates!=null)
				
				//commit all task 
				try 
				{
					Thread.sleep(conf.getSleepTime()*1000);
				} catch (InterruptedException e) {} 
				
				
			}//end of while 
			
		} catch (AgentServiceException e1)
		{
			unCatchException(e1,conf); 
		} 
	}

	
	/**
	 * Informs the server in case of fail in the main loop.
	 * Trying twice to send a response if failed to communicate.
	 * 
	 * @param e1 -   uncatched exception
	 * @param conf - agent configuration 
	 * @param net  - the communicate module for sending the task 
	 */
	private static void unCatchException(AgentServiceException e1,AgentServiceConf conf)
	{
		
		Communicate net;
		try 
		{
			net = new Communicate();
		}
		catch (AgentServiceException e3)
		{
			//the agent will be dead without notice to server because problem in connection 
			return;
		} 
		
		String errorMsg=conf.getAgentName()+"- Unexpected error : "+e1.getMessage()+"\n"+"agent fall - RIP";  
		
		ACK ack = new ACK(); 
		ack.setOK(false); 
		ack.setErrorMsg(errorMsg); 
		ack.setFullExceptionString(ExceptionHelper.getCustomStackTrace(e1)); 
		
		try
		{
			net.sendResponse(ack, conf);
		} 
		catch (AgentServiceException e) 
		{
			//try again 
			try
			{
				net.sendResponse(ack, conf);
			} catch (AgentServiceException e2) {}
		}
		
	}

	
	/**
	 * Creates new a agent service configuration from the file conf.cnf
	 * that stored in json format. Initialize AgentServiceConf object 
	 * with the string of configurations it got.
	 * 
	 * @throws AgentServiceException in case that it cannot open\read the
	 * 		   config file.
	 */
	private static void getConf() throws AgentServiceException 
	{
		//read the json string that contain the properties from the file 
		File confFile = new File("conf.cnf"); 
		FileReader fr;
		
		try 
		{
			fr = new FileReader(confFile);
		} 
		catch (FileNotFoundException e) 
		{
			throw new AgentServiceException("cound not file the configuration file - conf.cnf",e); 
		}
		
		char[] buffer = new  char[(int)confFile.length()];
		
		try 
		{
			fr.read(buffer);
		} 
		catch (IOException e) 
		{
			throw new AgentServiceException("problem to read from the configuration file",e); 
		}
		finally
		{
			try 
			{
				fr.close();
			} catch (IOException e) {}
		}
		
		String jsonConfStr = new String(buffer); 
		
	    //and use the json conf contractor 
	    conf = AgentServiceConf.IntallConf(jsonConfStr); 
	   
		
	}

}
