package Logger;

import java.io.File;
import java.util.Date;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


/**
 * This class use as adapter for the log4j 
 * for changing encryption of the log 
 */
public class AgentServiceLogger
{
	/** Logger object */
	static Logger logger = Logger.getLogger(AgentServiceLogger.class);
	
	/** private singletone instance of logger */
	static  AgentServiceLogger inst = null; 
	
	private AgentServiceLogger() {}
	
	
	/**
	 * Getting the instance of the logger as singletone
	 * @return
	 */
	public static AgentServiceLogger getInstance()
	{
		if(inst == null)
		{
			return new AgentServiceLogger(); 
		}
		return inst; 
	}
	
	/**
	 * Configuring log4j with the properties file
	 */
	public static  void init()
	{
		String slash = System.getProperty("file.separator"); 
		String path = new File(".").getAbsolutePath()+slash+"logs"+slash+"logConf.cnf" ; 
		PropertyConfigurator.configure(path);
		logger.debug(new Date().toString()+  "  -> start-logging"); 
	}
	
	/**
	 * Inserts info message into the log 
	 * @param msg
	 */
	public void info(String msg)
	{
		String newMsg=editMessage(msg); 
		logger.info(newMsg); 
		
	}
	
	/**
	 * Adds the current date to the message
	 * @param msg
	 * @return
	 */
	private String editMessage(String msg) 
	{
		String nowDate = getDateNow(); 
		return nowDate+ " -> " + msg; 
	}

	private String getDateNow() {
		return new Date().toString(); 
	}

	/**
	 * Inserts debug message into the log 
	 * @param msg
	 */
	public void debug(String msg)
	{
		String newMsg=editMessage(msg); 
		logger.debug(newMsg); 
	}
	
	/**
	 * Inserts fatal message into the log 
	 * @param msg
	 */
	public void fatal(String msg)
	{
		String newMsg=editMessage(msg); 
		logger.fatal(newMsg);
		
	}
	
	/**
	 * Inserts error message into the log 
	 * @param msg
	 */
	public void error(String msg)
	{
		String newMsg=editMessage(msg); 
		logger.error(newMsg);
	}
	
	/**
	 * Inserts warn message into the log 
	 * @param msg
	 */
	public void warn(String msg)
	{
		String newMsg=editMessage(msg); 
		logger.warn(newMsg);
		
	}

}
