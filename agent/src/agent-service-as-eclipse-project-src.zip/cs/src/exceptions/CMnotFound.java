package exceptions;


/**
 * Exception that requires actions
 *
 */
public class CMnotFound extends CMbasicException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CMnotFound(String msg, Throwable cause)
	{
		
	}
}
