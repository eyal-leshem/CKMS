package exceptions;

public class CMbasicException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
