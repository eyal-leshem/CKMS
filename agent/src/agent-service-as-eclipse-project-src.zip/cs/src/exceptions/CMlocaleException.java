package exceptions;


/**
 * Global exception, not needed special actions
 *
 */
public class CMlocaleException extends CMbasicException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CMlocaleException(String msg, Throwable cause)
	{
		
	}
}
