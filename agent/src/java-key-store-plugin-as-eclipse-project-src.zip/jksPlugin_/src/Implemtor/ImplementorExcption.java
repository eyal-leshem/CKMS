package Implemtor;


/**
 * Handles implementor exceptions
 */
public class ImplementorExcption extends Exception 
{
	
	public ImplementorExcption(String msg) 
	{
		super(msg); 
	}
	
	
	/**
	 * Handles exception occurred in implementation.
	 * @param msg	-	 description message
	 * @param e		-    occurred exception object 
	 */
	public ImplementorExcption(String msg,Throwable e)
	{
		super(msg,e); 
	}
	

}
