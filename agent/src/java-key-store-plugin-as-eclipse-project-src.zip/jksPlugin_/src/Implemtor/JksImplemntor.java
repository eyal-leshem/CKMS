package Implemtor;

import java.io.File;
import java.io.FileReader;
import java.math.BigInteger;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import javax.crypto.SecretKey;

import mjson.Json;

import MykeyTool.*;


/**
 * Java Key Store Implementor
 */
public class JksImplemntor extends Implementor 
{
	/** default value to the keystore type*/
	public final String  defulatStoreType = "JCEKS";
	
	/** default value to the key store implementor*/
	public final String  defulatImpName = "keyStoreImplementor"; 
   
	/** key store path */
    String ksPath; 
    
    /** key store password */
    String ksPassword; 
    
    /** key store type*/
    String ksType; 
    
    /** trust store path*/
    String tsPath;
    
    /** trust store password*/
    String tsPassword; 
    
    /** trust store type*/
    String tsType;
  
    
    /** key store key tool utility*/
    MyKeyTool ksKeyTool;
    
    /** trust store key tool utility*/
    MyKeyTool tsKeyTool; 
    
    
    /** file for storing last alias name*/
    File numAlias = new File("numAlias");
    
    
    /**
     * Initializes JKS implementor object
     * Sets the default values unless values were passed
     * Creates and configures trust store and key store 
     * using key tool with passed configuration.
     * 
     * @param params	- string with initialization values
     * @throws Exception
     */
    public JksImplemntor(String params) throws  Exception
    {
    	
    	/*get the parameters of the implementor 
    	that encoded in json */
    	
    	//read from json  
    	Json json = Json.read(params);
    	
    	//get ks params 
    	ksPassword = (String)json.at("ksPassword").getValue(); 
    	ksPath = (String)json.at("ksPath").getValue();
    	
    	
    	//get the trust store parms 
    	tsPassword = (String)json.at("tsPassword").getValue(); 
    	tsPath = (String)json.at("tsPath").getValue();    	
    		
    	    	
    	//set the name of this implementor 
    	//the default is "Jksimplemntor" 
    	if(json.at("name") == null)
    	{
    		name = "defulatImpName";
    	}
    	else
    	{
    		name = (String)json.at("name").getValue(); 
    	}
    	
    	//get type of keystore 
    	if(json.at("ksType") == null)
    	{
    		this.ksType = defulatStoreType; 
    	}
    	else
    	{
    		this.ksType = (String)json.at("ksType").getValue(); 
    	}
    	
    	//get type of trust sotre 
    	//case no proprty ane such trustsote we assume that is the same type of keystore 
    	if(json.at("tsType") == null)
    	{
    		this.tsType = this.tsType; 
    	}
    	else
    	{
    		this.tsType = (String)json.at("tsType").getValue();
    	}
    	    	
    	
    	//load the trust store  
    	
    	//Configure the key tool (use key store type jceks- for saving private keys); 
    	MyKeyToolConf ksconf = new MyKeyToolConf(ksPath, ksPassword); 
    	ksconf.setKeyStoreType(ksType);
    	
    	//create new keytool object and new keystore 
    	ksKeyTool = new MyKeyTool(ksconf);
    	
    	if(!(new File(ksPath).exists()))
    	{
    		ksKeyTool.createNewKs();   
    	}
    	//create the truststore  -
    	
    	//Configure the key tool (use key store type jceks- for saving private keys); 
    	MyKeyToolConf tsconf = new MyKeyToolConf(tsPath, tsPassword); 
    	tsconf.setKeyStoreType(tsType);
    	
    	//create new keytool object and new keystore 
    	tsKeyTool = new MyKeyTool(tsconf);
    	
    	if(!(new File(tsPath).exists()))
    	{
    		tsKeyTool.createNewKs();
    	}
	}
	
	
    /**
     * Generates public-private key pair and certificate with passed alias and initialization string
     * @return	- certificate generated
     * @throws	- ImplementorExcption in case it cannot generate a keys
     */
	@Override
	public Certificate genrateKeyPair(String dName, String alias) throws ImplementorExcption
	{
		try
		{
			//Generate certificate  
			Certificate cert = ksKeyTool.genartePrivatekey(alias, dName);
			return cert;
			
		}
		catch (Exception e)
		{
			throw new ImplementorExcption("can't genarte the key",e);  
		}	
	}
	


	/**
	 * Generates secret key with passed alias and initialization string
     * @return	- key generated
     * @throws	- ImplementorExcption in case it cannot generate a key
	 */
	@Override
	public SecretKey genrateSecertKey(String alg,String alias) throws ImplementorExcption 
	{
		SecretKey key; 
		try 
		{
			key = ksKeyTool.genrateSecretKey(alias, alg);
		}
		catch (MyKeyToolBaseExctpion e)
		{
			throw new ImplementorExcption("problem to genrate the key", e) ; 
		} 
		
		return key;
	}

	/**
	 * Installs a secret key with passed alias and initialization string into the key store
     * @return	- true in success
     * @throws	- ImplementorExcption in case it cannot store a key in key store
	 */
	@Override
	public boolean installSecertKey(SecretKey key,String alias) throws ImplementorExcption 
	{
		//try to add the secret key 
		try
		{
			tsKeyTool.addSecretKey(key,alias); 
		}
		catch (Exception e) 
		{
			throw new ImplementorExcption("problem to store the key in the keyStore", e) ; 
		}
		return true;
	}

	
	/**
	 * Installs a certificate with passed alias and initialization string into the trust store
     * @return	- true in success
     * @throws	- ImplementorExcption in case it cannot store a cert in trust store
	 */
	@Override
	public boolean installTrustCert(Certificate cert,String alias) 
	{
		try
		{		
			tsKeyTool.addTrustCert(cert, alias);
			return true;
			
		}
		catch (Exception e) 
		{
			return true; 
		}
		
		
	}
	
	
	/**
	 * Removes a certificate from the trust store and a public key from the key store
     * @return	- true in success
     * @throws	- ImplementorExcption in case of problem in removal
	 */
	@Override
	public boolean removeCertificate(BigInteger serialNumber)
			throws ImplementorExcption 
	{
		
		try
		{
			ksKeyTool.deleteFromks(serialNumber); 
			tsKeyTool.deleteFromks(serialNumber); 
		}
		catch (MyKeyToolBaseExctpion e)
		{
			throw new ImplementorExcption("can't delete certifcate with serail number "+serialNumber+"from key store",e);
		}
		
		return true; 
	}
	
	
	/**
	 * Returns all the algorithms used in key tool for encryption
     * @return	- true in success
     * @throws	- ImplementorExcption in case of problem in removal
	 */
	@Override
	public ArrayList<String> getAlgorithms()
	{
		return ksKeyTool.getAlgorithms();
	}
	
	
	/**
	 * 
	 * @param argv
	 * @throws Exception
	 */
	public static void main(String[] argv) throws Exception
	{
		
		File f = new File("conf.cnf"); 
		char[] buffer = new char[(int)f.length()]; 
		FileReader fr = new FileReader(f);
		fr.read(buffer);
		String jsonConf = new String(buffer); 
		
		Implementor imp = new JksImplemntor(jsonConf);
		imp.getAlgorithms();
		imp.genrateSecertKey("AES","3");
		Certificate cert = imp.genrateKeyPair("CN=a","c"); 
		//imp.installTrustCert(cert, "b"); 
		imp.removeCertificate(((X509Certificate)cert).getSerialNumber()); 
		
	}
	
	

}
