package MykeyTool;


/**
 * Base class for all the MyKeyTool exceptions
 */
public class MyKeyToolBaseExctpion extends Exception
{
	
	public MyKeyToolBaseExctpion(String errorMsg) 
	{
		super(errorMsg);
	}
	
	/**
	 * Handles exception occurred in implementation.
	 * @param msg	-	 description message
	 * @param e		-    occurred exception object 
	 */
	public MyKeyToolBaseExctpion(String errorMsg,Throwable cause) 
	{
		super(errorMsg,cause); 
	};

}
