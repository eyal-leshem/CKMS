package MykeyTool;

/**
 * Handles key tool IO exceptions
 */
public class MykeyToolIoException extends MyKeyToolBaseExctpion
{
	
	public MykeyToolIoException(String message) 
	{
		super(message); 
	}
	
	/**
	 * Handles exception occurred in implementation in IO.
	 * @param msg	-	 description message
	 * @param e		-    occurred exception object 
	 */
	public MykeyToolIoException(String errorMsg, Throwable cause)
	{
		super(errorMsg, cause);
	}

}
