package MykeyTool;

public class MykeyToolIoException extends MyKeyToolBaseExctpion {
	
	public MykeyToolIoException(String message) {
		super(message); 
	}
	public MykeyToolIoException(String errorMsg, Throwable cause) {
		super(errorMsg, cause);
	}

}
