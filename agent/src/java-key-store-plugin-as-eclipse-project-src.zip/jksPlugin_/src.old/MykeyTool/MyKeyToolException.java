package MykeyTool;

public class MyKeyToolException extends MyKeyToolBaseExctpion {

	public MyKeyToolException(String message) {
		super(message); 
	}
	public MyKeyToolException(String errorMsg, Throwable cause) {
		super(errorMsg, cause);
	}

}
