This directory contains useful PHP Code which
makes use of the PHP-Java Bridge

See the individual files for more info.

Especially useful is jikes_compiler.php 
which provides an automatic build environment
for use with the php java bridge. 
(Requires jikes executable)