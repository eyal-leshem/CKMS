
<!-- login form -->  

<html> 
<link  rel="stylesheet" type="text/css" href="boot/docs/assets/css/bootstrap.css" />
	<body>
	
	
	<BR><BR><BR><BR><BR><BR><BR><BR><BR>
		<div class="row">
			<div class="span5">
				<img src="white.gif"  width="130" height="130"/>
			</div>
			<div class="span2">
				<img src="white.gif"  width="130" height="130"/>
			</div>
			
			<div class="span4">
					 
					<form method="post" action="checkPass.php" class="well">
						userName: <input type="text" name="userName" /><br />
						Password: <input type="password" name="password" /> <br /> 
						<input type="submit" value="Submit" />				
					</form> 
			</div>
			
			<div class="span4">
				<img src="white.gif"  width="130" height="130" />
			</div>
		
	</body>
</html> 
